package edu.epam.daotask.constant;

public enum PrintingCenter{
    BREST,
    MINSK,
    GRODNO,
    GOMEL,
    VITEBSK,
    MOGILEV,
    LONDON,
    MOSKOW
}
